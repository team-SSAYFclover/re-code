package com.clover.recode.domain.user.repository;

import com.clover.recode.domain.user.entity.Setting;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SettingRepository extends JpaRepository<Setting, Long> {


}
