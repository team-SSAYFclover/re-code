package com.clover.recode.domain.auth.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginReq {

  private String authorizationCode;

}
