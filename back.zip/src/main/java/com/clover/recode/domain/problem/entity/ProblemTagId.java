package com.clover.recode.domain.problem.entity;

import java.io.Serializable;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProblemTagId implements Serializable {
    // 복합키를 처리하기 위한 Serializable 인터페이스 구현
    private Long problem; // 문제 아이디
    private Byte tag; // 문제 분류 아이디
}
