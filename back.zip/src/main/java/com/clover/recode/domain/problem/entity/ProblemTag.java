package com.clover.recode.domain.problem.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "problem_tag")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@IdClass(ProblemTagId.class)
public class ProblemTag {

    @Id
    @ManyToOne
    @JoinColumn(name = "problem_id")
    private Problem problem;

    @Id
    @ManyToOne
    @JoinColumn(name = "tag_id")
    private Tag tag;
}
